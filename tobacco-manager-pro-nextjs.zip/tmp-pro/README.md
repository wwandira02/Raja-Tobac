# Tobacco Manager Pro

Sistem manajemen bisnis internal untuk distribusi & ritel tembakau. Dibangun dengan
Next.js 15 (App Router), TypeScript, Tailwind CSS, dan Supabase.

## Fitur

- **Dashboard** — statistik pendapatan/laba harian & bulanan, grafik penjualan, peringatan stok
- **Produk** — CRUD produk, kalkulasi margin & profit otomatis
- **Penjualan** — catat transaksi, stok & laba dihitung otomatis (trigger database)
- **Pembelian** — catat dari distributor, stok bertambah otomatis
- **Inventaris** — nilai stok, riwayat pergerakan, penyesuaian manual
- **Distributor** — data mitra, riwayat & total transaksi
- **Pengeluaran** — kategori transportasi, operasional, gaji, dll
- **Laporan** — harian/bulanan/tahunan, ekspor CSV, cetak
- **Autentikasi** — login khusus pemilik via Supabase Auth, sesi dikelola oleh middleware

## Setup

### 1. Buat proyek Supabase
Buka [supabase.com](https://supabase.com), buat proyek baru, lalu buka **SQL Editor** dan
jalankan seluruh isi `supabase/schema.sql`. Ini akan membuat semua tabel, relasi, trigger
otomatis (stok bertambah/berkurang), dan Row Level Security.

### 2. Buat akun pemilik
Di Supabase dashboard → **Authentication → Users → Add User**, buat satu akun (email +
password) untuk pemilik usaha. Sistem ini dirancang untuk satu akun owner; tidak ada
pendaftaran mandiri (sign-up) di aplikasi.

### 3. Konfigurasi environment
```bash
cp .env.local.example .env.local
```
Isi `NEXT_PUBLIC_SUPABASE_URL` dan `NEXT_PUBLIC_SUPABASE_ANON_KEY` dari
**Project Settings → API** di dashboard Supabase.

### 4. Install & jalankan
```bash
npm install
npm run dev
```
Buka [http://localhost:3000](http://localhost:3000) — Anda akan diarahkan ke halaman login.

### 5. (Opsional) Data contoh
Anda bisa menambahkan produk, distributor, dan transaksi awal langsung dari UI setelah
login, atau melalui **Table Editor** di Supabase.

## Struktur Proyek

```
app/                  Halaman (App Router)
  page.tsx            Dashboard
  products/            Manajemen produk
  sales/               Penjualan
  purchases/           Pembelian
  inventory/           Inventaris
  distributors/        Distributor
  expenses/            Pengeluaran
  reports/             Laporan
  settings/            Pengaturan akun
  login/               Halaman login
components/
  ui/                  Komponen dasar (button, card, input, dialog, badge)
  layout/              Sidebar, topbar, app shell
  charts/              Grafik (Recharts)
  dashboard/           Kartu statistik
lib/
  supabase/            Klien Supabase (browser & server)
  database.types.ts    Tipe TypeScript untuk tabel database
  calculations.ts      Rumus profit, margin, agregasi
  reports.ts           Logika laporan periode
  data.ts              Helper fetch data sisi server
  utils.ts             Formatter (mata uang, tanggal, dll)
supabase/
  schema.sql           Skema lengkap: tabel, trigger, RLS, index
middleware.ts          Proteksi rute (redirect ke /login jika belum masuk)
```

## Cara kerja stok otomatis

Perhitungan stok **tidak** dilakukan di sisi client — semuanya ditangani oleh trigger
PostgreSQL di `supabase/schema.sql`:
- Insert ke `purchase_items` → stok produk bertambah + log inventaris "masuk"
- Insert ke `sale_items` → stok produk berkurang + log inventaris "keluar"
- Delete pada salah satu → stok dikembalikan otomatis

Ini menjamin stok selalu konsisten meski ada banyak pengguna atau perangkat yang mengakses
bersamaan.

## Deploy

Proyek ini siap di-deploy ke [Vercel](https://vercel.com): hubungkan repo, tambahkan
environment variables yang sama seperti `.env.local`, lalu deploy. Next.js akan otomatis
mendeteksi App Router dan middleware.

## Catatan keamanan

- Row Level Security aktif di semua tabel — hanya pengguna yang sudah login (`authenticated`)
  yang bisa membaca/menulis data.
- Tidak ada halaman pendaftaran publik; tambahkan pengguna baru manual dari dashboard Supabase.
- Untuk multi-staff dengan hak akses berbeda, kembangkan kolom `role` di tabel `profiles`
  dan perketat policy RLS sesuai kebutuhan.
