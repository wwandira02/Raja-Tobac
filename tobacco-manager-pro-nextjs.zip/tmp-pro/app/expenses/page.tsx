"use client";
import { useEffect, useState } from "react";
import { AppShell } from "@/components/layout/app-shell";
import { StatCard } from "@/components/dashboard/stat-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input, Label, Select, Textarea } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog } from "@/components/ui/dialog";
import { createClient } from "@/lib/supabase/client";
import type { Expense } from "@/lib/database.types";
import { formatCurrency, formatDate, todayStr, monthStr } from "@/lib/utils";

const CATS = ["Transportasi", "Operasional", "Kemasan", "Listrik & Utilitas", "Gaji Karyawan", "Lain-lain"] as const;

export default function ExpensesPage() {
  const supabase = createClient();
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [open, setOpen] = useState(false);
  const [date, setDate] = useState(todayStr());
  const [category, setCategory] = useState<string>(CATS[0]);
  const [amount, setAmount] = useState(0);
  const [description, setDescription] = useState("");

  async function load() {
    const { data } = await supabase.from("expenses").select("*").order("date", { ascending: false });
    setExpenses((data as Expense[]) ?? []);
  }
  useEffect(() => { load(); }, []);

  function openAdd() { setDate(todayStr()); setCategory(CATS[0]); setAmount(0); setDescription(""); setOpen(true); }

  async function handleSave() {
    if (amount <= 0) return alert("Jumlah harus lebih dari 0");
    await supabase.from("expenses").insert({ date, category, amount, description });
    setOpen(false); load();
  }
  async function handleDelete(id: string) {
    if (!confirm("Hapus pengeluaran ini?")) return;
    await supabase.from("expenses").delete().eq("id", id);
    load();
  }

  const total = expenses.reduce((a, e) => a + e.amount, 0);
  const monthTotal = expenses.filter((e) => e.date.startsWith(monthStr())).reduce((a, e) => a + e.amount, 0);

  return (
    <AppShell title="Pengeluaran" subtitle="Catat biaya operasional bisnis">
      <div className="mb-5 grid gap-4 sm:grid-cols-3">
        <StatCard label="Total Pengeluaran" value={formatCurrency(total)} delta="seluruh waktu" />
        <StatCard label="Pengeluaran Bulan Ini" value={formatCurrency(monthTotal)} delta={monthStr()} />
        <StatCard label="Rata-rata / Transaksi" value={formatCurrency(expenses.length ? total / expenses.length : 0)} delta={`${expenses.length} transaksi`} />
      </div>
      <div className="mb-4 flex justify-end"><Button onClick={openAdd}>+ Tambah Pengeluaran</Button></div>
      <Card className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border text-left text-[11.5px] uppercase tracking-wide text-muted-foreground">
              <th className="p-3">Tanggal</th><th className="p-3">Kategori</th><th className="p-3">Deskripsi</th><th className="p-3">Jumlah</th><th className="p-3" />
            </tr>
          </thead>
          <tbody>
            {expenses.length === 0 && <tr><td colSpan={5} className="p-8 text-center text-muted-foreground">Belum ada pengeluaran tercatat.</td></tr>}
            {expenses.map((e) => (
              <tr key={e.id} className="border-b border-border hover:bg-muted/40">
                <td className="p-3">{formatDate(e.date)}</td>
                <td className="p-3"><Badge tone="warn">{e.category}</Badge></td>
                <td className="p-3">{e.description || "-"}</td>
                <td className="p-3 font-semibold">{formatCurrency(e.amount)}</td>
                <td className="p-3"><Button size="sm" variant="danger" onClick={() => handleDelete(e.id)}>Hapus</Button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>

      <Dialog open={open} onClose={() => setOpen(false)} title="Tambah Pengeluaran" footer={<>
        <Button variant="outline" onClick={() => setOpen(false)}>Batal</Button>
        <Button onClick={handleSave}>Simpan</Button>
      </>}>
        <div className="space-y-3.5">
          <div><Label>Tanggal</Label><Input type="date" value={date} onChange={(e) => setDate(e.target.value)} /></div>
          <div><Label>Kategori</Label>
            <Select value={category} onChange={(e) => setCategory(e.target.value)}>
              {CATS.map((c) => <option key={c}>{c}</option>)}
            </Select>
          </div>
          <div><Label>Jumlah</Label><Input type="number" value={amount} onChange={(e) => setAmount(Number(e.target.value))} /></div>
          <div><Label>Deskripsi</Label><Textarea rows={2} value={description} onChange={(e) => setDescription(e.target.value)} /></div>
        </div>
      </Dialog>
    </AppShell>
  );
}
