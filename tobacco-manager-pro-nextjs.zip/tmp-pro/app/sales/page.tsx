"use client";
import { useEffect, useState } from "react";
import { AppShell } from "@/components/layout/app-shell";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input, Label, Select } from "@/components/ui/input";
import { Dialog } from "@/components/ui/dialog";
import { createClient } from "@/lib/supabase/client";
import type { Product, Sale, SaleItem } from "@/lib/database.types";
import { formatCurrency, formatDate, todayStr } from "@/lib/utils";

export default function SalesPage() {
  const supabase = createClient();
  const [sales, setSales] = useState<(Sale & { sale_items: (SaleItem & { products: Pick<Product, "name"> })[] })[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(true);

  const [date, setDate] = useState(todayStr());
  const [productId, setProductId] = useState("");
  const [qty, setQty] = useState(1);
  const [price, setPrice] = useState(0);

  async function load() {
    setLoading(true);
    const [{ data: s }, { data: p }] = await Promise.all([
      supabase.from("sales").select("*, sale_items(*, products(name))").order("date", { ascending: false }).limit(100),
      supabase.from("products").select("*").order("name"),
    ]);
    setSales((s as any) ?? []);
    setProducts((p as Product[]) ?? []);
    setLoading(false);
  }
  useEffect(() => { load(); }, []);

  function openAdd() {
    if (products.length === 0) return alert("Tambahkan produk terlebih dahulu");
    const first = products[0];
    setProductId(first.id); setQty(1); setPrice(first.selling_price); setDate(todayStr());
    setOpen(true);
  }

  function onProductChange(id: string) {
    setProductId(id);
    const p = products.find((x) => x.id === id);
    if (p) setPrice(p.selling_price);
  }

  const selected = products.find((p) => p.id === productId);
  const total = qty * price;
  const profit = selected ? qty * (price - selected.purchase_price) : 0;

  async function handleSave() {
    if (!selected) return;
    if (qty <= 0) return alert("Jumlah harus lebih dari 0");
    if (qty > selected.stock) return alert(`Stok tidak mencukupi (${selected.stock} tersedia)`);

    const number = "INV-" + todayStr().replace(/-/g, "") + "-" + (sales.length + 1);
    const { data: sale, error } = await supabase
      .from("sales")
      .insert({ number, date, total, profit })
      .select()
      .single();
    if (error || !sale) return alert("Gagal menyimpan penjualan: " + error?.message);

    await supabase.from("sale_items").insert({
      sale_id: sale.id, product_id: productId, quantity: qty,
      selling_price: price, purchase_price_snapshot: selected.purchase_price,
    });
    // stock decrement + inventory log handled automatically by DB trigger
    setOpen(false);
    load();
  }

  async function handleDelete(id: string) {
    if (!confirm("Hapus transaksi ini? Stok akan dikembalikan.")) return;
    await supabase.from("sales").delete().eq("id", id); // cascades to sale_items -> trigger restores stock
    load();
  }

  return (
    <AppShell title="Penjualan" subtitle="Catat transaksi penjualan harian">
      <div className="mb-4 flex justify-end"><Button onClick={openAdd}>+ Catat Penjualan</Button></div>
      <Card className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border text-left text-[11.5px] uppercase tracking-wide text-muted-foreground">
              <th className="p-3">No. Nota</th><th className="p-3">Tanggal</th><th className="p-3">Produk</th>
              <th className="p-3">Qty</th><th className="p-3">Total</th><th className="p-3">Laba</th><th className="p-3" />
            </tr>
          </thead>
          <tbody>
            {loading && <tr><td colSpan={7} className="p-8 text-center text-muted-foreground">Memuat...</td></tr>}
            {!loading && sales.length === 0 && <tr><td colSpan={7} className="p-8 text-center text-muted-foreground">Belum ada transaksi penjualan.</td></tr>}
            {sales.map((s) => (
              <tr key={s.id} className="border-b border-border hover:bg-muted/40">
                <td className="p-3">{s.number}</td>
                <td className="p-3">{formatDate(s.date)}</td>
                <td className="p-3">{s.sale_items.map((i) => i.products?.name).join(", ")}</td>
                <td className="p-3">{s.sale_items.reduce((a, i) => a + i.quantity, 0)}</td>
                <td className="p-3 font-semibold">{formatCurrency(s.total)}</td>
                <td className="p-3 text-brand-green800">{formatCurrency(s.profit)}</td>
                <td className="p-3"><Button size="sm" variant="danger" onClick={() => handleDelete(s.id)}>Hapus</Button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>

      <Dialog open={open} onClose={() => setOpen(false)} title="Catat Penjualan" footer={<>
        <Button variant="outline" onClick={() => setOpen(false)}>Batal</Button>
        <Button onClick={handleSave}>Simpan</Button>
      </>}>
        <div className="space-y-3.5">
          <div><Label>Tanggal</Label><Input type="date" value={date} onChange={(e) => setDate(e.target.value)} /></div>
          <div><Label>Produk</Label>
            <Select value={productId} onChange={(e) => onProductChange(e.target.value)}>
              {products.map((p) => <option key={p.id} value={p.id}>{p.name} — stok {p.stock}</option>)}
            </Select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><Label>Jumlah</Label><Input type="number" min={1} value={qty} onChange={(e) => setQty(Number(e.target.value))} /></div>
            <div><Label>Harga Jual (per unit)</Label><Input type="number" value={price} onChange={(e) => setPrice(Number(e.target.value))} /></div>
          </div>
          <p className="text-sm text-muted-foreground">Total: {formatCurrency(total)} &middot; Estimasi laba: {formatCurrency(profit)}</p>
        </div>
      </Dialog>
    </AppShell>
  );
}
