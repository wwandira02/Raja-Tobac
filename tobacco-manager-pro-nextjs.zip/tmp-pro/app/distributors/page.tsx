"use client";
import { useEffect, useState } from "react";
import { Phone, MapPin } from "lucide-react";
import { AppShell } from "@/components/layout/app-shell";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input, Label, Textarea } from "@/components/ui/input";
import { Dialog } from "@/components/ui/dialog";
import { createClient } from "@/lib/supabase/client";
import type { Distributor, Purchase } from "@/lib/database.types";
import { formatCurrency } from "@/lib/utils";

const empty = { name: "", phone: "", address: "", city: "", notes: "" };

export default function DistributorsPage() {
  const supabase = createClient();
  const [distributors, setDistributors] = useState<Distributor[]>([]);
  const [purchases, setPurchases] = useState<Purchase[]>([]);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Distributor | null>(null);
  const [form, setForm] = useState(empty);

  async function load() {
    const [{ data: d }, { data: p }] = await Promise.all([
      supabase.from("distributors").select("*").order("name"),
      supabase.from("purchases").select("*"),
    ]);
    setDistributors((d as Distributor[]) ?? []);
    setPurchases((p as Purchase[]) ?? []);
  }
  useEffect(() => { load(); }, []);

  function openAdd() { setEditing(null); setForm(empty); setOpen(true); }
  function openEdit(d: Distributor) {
    setEditing(d);
    setForm({ name: d.name, phone: d.phone ?? "", address: d.address ?? "", city: d.city ?? "", notes: d.notes ?? "" });
    setOpen(true);
  }
  async function handleSave() {
    if (!form.name.trim()) return alert("Nama distributor wajib diisi");
    if (editing) await supabase.from("distributors").update(form).eq("id", editing.id);
    else await supabase.from("distributors").insert(form);
    setOpen(false); load();
  }
  async function handleDelete(id: string) {
    if (!confirm("Hapus distributor ini?")) return;
    await supabase.from("distributors").delete().eq("id", id);
    load();
  }

  return (
    <AppShell title="Distributor" subtitle="Data mitra pemasok dan riwayat transaksi">
      <div className="mb-4 flex justify-end"><Button onClick={openAdd}>+ Tambah Distributor</Button></div>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {distributors.length === 0 && <p className="text-muted-foreground">Belum ada distributor.</p>}
        {distributors.map((d) => {
          const list = purchases.filter((p) => p.distributor_id === d.id);
          const totalSpend = list.reduce((a, p) => a + p.total, 0);
          return (
            <Card key={d.id} className="p-5">
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-display text-[15.5px]">{d.name}</h3>
                  <div className="mt-0.5 text-[12.5px] text-muted-foreground">{d.city || "-"}</div>
                </div>
                <div className="flex gap-1.5">
                  <Button size="sm" variant="outline" onClick={() => openEdit(d)}>Edit</Button>
                  <Button size="sm" variant="danger" onClick={() => handleDelete(d.id)}>Hapus</Button>
                </div>
              </div>
              <div className="my-3.5 space-y-1 text-[13px] text-muted-foreground">
                {d.phone && <div className="flex items-center gap-1.5"><Phone size={13} />{d.phone}</div>}
                {d.address && <div className="flex items-center gap-1.5"><MapPin size={13} />{d.address}</div>}
              </div>
              <div className="flex gap-5 border-t border-border pt-3">
                <div><div className="text-[11px] text-muted-foreground">Total Transaksi</div><div className="font-bold">{list.length}</div></div>
                <div><div className="text-[11px] text-muted-foreground">Total Belanja</div><div className="font-bold">{formatCurrency(totalSpend)}</div></div>
              </div>
            </Card>
          );
        })}
      </div>

      <Dialog open={open} onClose={() => setOpen(false)} title={editing ? "Edit Distributor" : "Tambah Distributor"} footer={<>
        <Button variant="outline" onClick={() => setOpen(false)}>Batal</Button>
        <Button onClick={handleSave}>{editing ? "Simpan" : "Tambah"}</Button>
      </>}>
        <div className="space-y-3.5">
          <div><Label>Nama Distributor</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
          <div className="grid grid-cols-2 gap-3">
            <div><Label>No. Telepon</Label><Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></div>
            <div><Label>Kota</Label><Input value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} /></div>
          </div>
          <div><Label>Alamat</Label><Input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} /></div>
          <div><Label>Catatan</Label><Textarea rows={2} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></div>
        </div>
      </Dialog>
    </AppShell>
  );
}
