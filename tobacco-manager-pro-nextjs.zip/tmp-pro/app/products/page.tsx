"use client";
import { useEffect, useState } from "react";
import { Search } from "lucide-react";
import { AppShell } from "@/components/layout/app-shell";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input, Label, Textarea } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog } from "@/components/ui/dialog";
import { createClient } from "@/lib/supabase/client";
import type { Product } from "@/lib/database.types";
import { formatCurrency, cn } from "@/lib/utils";
import { marginPercent } from "@/lib/calculations";

const empty = {
  name: "", category: "", brand: "", purchase_price: 0, selling_price: 0,
  stock: 0, min_stock: 0, unit: "Bungkus", notes: "",
};

export default function ProductsPage() {
  const supabase = createClient();
  const [products, setProducts] = useState<Product[]>([]);
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Product | null>(null);
  const [form, setForm] = useState<typeof empty>(empty);
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    const { data } = await supabase.from("products").select("*").order("name");
    setProducts((data as Product[]) ?? []);
    setLoading(false);
  }
  useEffect(() => { load(); }, []);

  function openAdd() { setEditing(null); setForm(empty); setOpen(true); }
  function openEdit(p: Product) {
    setEditing(p);
    setForm({
      name: p.name, category: p.category ?? "", brand: p.brand ?? "",
      purchase_price: p.purchase_price, selling_price: p.selling_price,
      stock: p.stock, min_stock: p.min_stock, unit: p.unit, notes: p.notes ?? "",
    });
    setOpen(true);
  }

  async function handleSave() {
    if (!form.name.trim()) return alert("Nama produk wajib diisi");
    if (editing) {
      await supabase.from("products").update(form).eq("id", editing.id);
    } else {
      await supabase.from("products").insert(form);
    }
    setOpen(false);
    load();
  }

  async function handleDelete(id: string) {
    if (!confirm("Hapus produk ini?")) return;
    await supabase.from("products").delete().eq("id", id);
    load();
  }

  const filtered = products.filter((p) =>
    `${p.name} ${p.brand} ${p.category}`.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <AppShell title="Manajemen Produk" subtitle="Kelola daftar produk, harga, dan stok minimum">
      <div className="mb-4 flex justify-end">
        <Button onClick={openAdd}>+ Tambah Produk</Button>
      </div>
      <div className="relative mb-4 max-w-sm">
        <Search className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" size={15} />
        <Input className="pl-9" placeholder="Cari produk, brand, atau kategori..." value={search} onChange={(e) => setSearch(e.target.value)} />
      </div>

      <Card className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border text-left text-[11.5px] uppercase tracking-wide text-muted-foreground">
              <th className="p-3">Produk</th><th className="p-3">Kategori</th><th className="p-3">Brand</th>
              <th className="p-3">Harga Beli</th><th className="p-3">Harga Jual</th><th className="p-3">Margin</th>
              <th className="p-3">Stok</th><th className="p-3">Status</th><th className="p-3" />
            </tr>
          </thead>
          <tbody>
            {loading && <tr><td colSpan={9} className="p-8 text-center text-muted-foreground">Memuat...</td></tr>}
            {!loading && filtered.length === 0 && <tr><td colSpan={9} className="p-8 text-center text-muted-foreground">Tidak ada produk ditemukan.</td></tr>}
            {filtered.map((p) => {
              const margin = marginPercent(p);
              return (
                <tr key={p.id} className="border-b border-border hover:bg-muted/40">
                  <td className="p-3">
                    <div className="font-semibold">{p.name}</div>
                    {p.notes && <div className="text-[11.5px] text-muted-foreground">{p.notes}</div>}
                  </td>
                  <td className="p-3">{p.category}</td>
                  <td className="p-3">{p.brand}</td>
                  <td className="p-3">{formatCurrency(p.purchase_price)}</td>
                  <td className="p-3">{formatCurrency(p.selling_price)}</td>
                  <td className="p-3">{margin.toFixed(1)}%</td>
                  <td className="p-3">{p.stock} {p.unit}</td>
                  <td className="p-3">
                    {p.stock <= 0 ? <Badge tone="danger">Habis</Badge> :
                      p.stock <= p.min_stock ? <Badge tone="warn">Menipis</Badge> :
                      <Badge tone="ok">Stok Aman</Badge>}
                  </td>
                  <td className="whitespace-nowrap p-3">
                    <Button size="sm" variant="outline" onClick={() => openEdit(p)}>Edit</Button>{" "}
                    <Button size="sm" variant="danger" onClick={() => handleDelete(p.id)}>Hapus</Button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </Card>

      <Dialog
        open={open}
        onClose={() => setOpen(false)}
        title={editing ? "Edit Produk" : "Tambah Produk"}
        footer={<>
          <Button variant="outline" onClick={() => setOpen(false)}>Batal</Button>
          <Button onClick={handleSave}>{editing ? "Simpan Perubahan" : "Tambah Produk"}</Button>
        </>}
      >
        <div className="space-y-3.5">
          <div><Label>Nama Produk</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
          <div className="grid grid-cols-2 gap-3">
            <div><Label>Kategori</Label><Input value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} /></div>
            <div><Label>Brand</Label><Input value={form.brand} onChange={(e) => setForm({ ...form, brand: e.target.value })} /></div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><Label>Harga Beli</Label><Input type="number" value={form.purchase_price} onChange={(e) => setForm({ ...form, purchase_price: Number(e.target.value) })} /></div>
            <div><Label>Harga Jual</Label><Input type="number" value={form.selling_price} onChange={(e) => setForm({ ...form, selling_price: Number(e.target.value) })} /></div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><Label>Stok Saat Ini</Label><Input type="number" value={form.stock} onChange={(e) => setForm({ ...form, stock: Number(e.target.value) })} /></div>
            <div><Label>Stok Minimum</Label><Input type="number" value={form.min_stock} onChange={(e) => setForm({ ...form, min_stock: Number(e.target.value) })} /></div>
          </div>
          <div><Label>Satuan</Label><Input value={form.unit} onChange={(e) => setForm({ ...form, unit: e.target.value })} /></div>
          <div><Label>Catatan</Label><Textarea rows={2} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></div>
        </div>
      </Dialog>
    </AppShell>
  );
}
