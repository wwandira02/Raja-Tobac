"use client";
import { useEffect, useState } from "react";
import { Printer, Download } from "lucide-react";
import { AppShell } from "@/components/layout/app-shell";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ExpenseDonutChart } from "@/components/charts/expense-donut-chart";
import { MonthlyRevenueChart } from "@/components/charts/monthly-revenue-chart";
import { createClient } from "@/lib/supabase/client";
import type { Product, Sale, SaleItem, Expense } from "@/lib/database.types";
import { formatCurrency, todayStr, monthStr } from "@/lib/utils";
import { buildPeriodReport, revenueGrowth, mostProfitableProducts } from "@/lib/reports";
import { totalRevenue } from "@/lib/calculations";

export default function ReportsPage() {
  const supabase = createClient();
  const [sales, setSales] = useState<Sale[]>([]);
  const [saleItems, setSaleItems] = useState<SaleItem[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [products, setProducts] = useState<Product[]>([]);

  useEffect(() => {
    (async () => {
      const [{ data: s }, { data: si }, { data: e }, { data: p }] = await Promise.all([
        supabase.from("sales").select("*"),
        supabase.from("sale_items").select("*"),
        supabase.from("expenses").select("*"),
        supabase.from("products").select("*"),
      ]);
      setSales((s as Sale[]) ?? []);
      setSaleItems((si as SaleItem[]) ?? []);
      setExpenses((e as Expense[]) ?? []);
      setProducts((p as Product[]) ?? []);
    })();
  }, []);

  const today = todayStr();
  const month = monthStr();
  const year = String(new Date().getFullYear());
  const lastYear = String(new Date().getFullYear() - 1);

  const daily = buildPeriodReport("Hari ini", sales, expenses, today, today);
  const monthly = buildPeriodReport("Bulan ini", sales, expenses, month + "-01", month + "-31");
  const yearly = buildPeriodReport("Tahun ini", sales, expenses, year + "-01-01", year + "-12-31");
  const growth = revenueGrowth(
    sales.filter((s) => s.date.startsWith(year)),
    sales.filter((s) => s.date.startsWith(lastYear))
  );

  const monthlyChart = Array.from({ length: 6 }).map((_, i) => {
    const d = new Date(); d.setMonth(d.getMonth() - (5 - i));
    const mk = d.toISOString().slice(0, 7);
    return { month: d.toLocaleDateString("id-ID", { month: "short", year: "2-digit" }), revenue: totalRevenue(sales.filter((s) => s.date.startsWith(mk))) };
  });

  const byCat: Record<string, number> = {};
  expenses.forEach((e) => { byCat[e.category] = (byCat[e.category] || 0) + e.amount; });
  const expenseChart = Object.entries(byCat).map(([name, value]) => ({ name, value }));

  const productMap = Object.fromEntries(products.map((p) => [p.id, p]));
  const ranked = mostProfitableProducts(saleItems);

  function exportCsv() {
    const rows = [["No Nota", "Tanggal", "Total", "Laba"]];
    sales.forEach((s) => rows.push([s.number, s.date, String(s.total), String(s.profit)]));
    const csv = rows.map((r) => r.map((c) => `"${c.replace(/"/g, '""')}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "laporan_penjualan.csv"; a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <AppShell title="Laporan" subtitle="Ringkasan performa harian, bulanan, dan tahunan">
      <div className="mb-4 flex flex-wrap gap-2.5">
        <Button variant="outline" onClick={() => window.print()}><Printer size={15} /> Cetak</Button>
        <Button variant="outline" onClick={exportCsv}><Download size={15} /> Ekspor CSV (Excel)</Button>
      </div>

      <div className="mb-5 grid gap-4 lg:grid-cols-3">
        <ReportCard title="Laporan Harian" sub={today} rows={[
          ["Pendapatan", formatCurrency(daily.revenue)], ["Laba Kotor", formatCurrency(daily.grossProfit)],
          ["Pengeluaran", formatCurrency(daily.expenses)], ["Laba Bersih", formatCurrency(daily.netProfit)],
        ]} />
        <ReportCard title="Laporan Bulanan" sub={month} rows={[
          ["Pendapatan", formatCurrency(monthly.revenue)], ["Laba Kotor", formatCurrency(monthly.grossProfit)],
          ["Pengeluaran", formatCurrency(monthly.expenses)], ["Laba Bersih", formatCurrency(monthly.netProfit)],
        ]} />
        <ReportCard title="Laporan Tahunan" sub={year} rows={[
          ["Pendapatan", formatCurrency(yearly.revenue)], ["Laba Kotor", formatCurrency(yearly.grossProfit)],
          ["Pengeluaran", formatCurrency(yearly.expenses)],
          ["Pertumbuhan Pendapatan", growth === null ? "Data tahun lalu belum ada" : `${growth >= 0 ? "+" : ""}${growth.toFixed(1)}%`],
        ]} />
      </div>

      <Card className="mb-5 p-5">
        <h3 className="mb-3 font-display text-[15.5px]">Tren Pendapatan (6 bulan)</h3>
        <MonthlyRevenueChart data={monthlyChart} />
      </Card>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card className="p-5">
          <h3 className="mb-3 font-display text-[15.5px]">Produk Paling Menguntungkan</h3>
          {ranked.length === 0 ? <p className="text-sm text-muted-foreground">Belum ada data penjualan.</p> : (
            <table className="w-full text-sm">
              <tbody>
                {ranked.map((r) => (
                  <tr key={r.productId} className="border-b border-border">
                    <td className="py-2">{productMap[r.productId]?.name ?? "(dihapus)"}</td>
                    <td className="py-2 text-right font-semibold text-brand-green800">{formatCurrency(r.profit)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </Card>
        <Card className="p-5">
          <h3 className="mb-3 font-display text-[15.5px]">Distribusi Pengeluaran</h3>
          {expenseChart.length === 0 ? <p className="text-sm text-muted-foreground">Belum ada pengeluaran.</p> : <ExpenseDonutChart data={expenseChart} />}
        </Card>
      </div>
    </AppShell>
  );
}

function ReportCard({ title, sub, rows }: { title: string; sub: string; rows: [string, string][] }) {
  return (
    <Card className="p-5">
      <div className="text-[14.5px] font-bold">{title}</div>
      <div className="mb-3 text-xs text-muted-foreground">{sub}</div>
      {rows.map(([k, v]) => (
        <div key={k} className="flex justify-between border-b border-border py-1.5 text-[13px] last:border-none">
          <span className="text-muted-foreground">{k}</span><strong>{v}</strong>
        </div>
      ))}
    </Card>
  );
}
