"use client";
import { useEffect, useState } from "react";
import { AppShell } from "@/components/layout/app-shell";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input, Label, Select, Textarea } from "@/components/ui/input";
import { Dialog } from "@/components/ui/dialog";
import { createClient } from "@/lib/supabase/client";
import type { Product, Purchase, PurchaseItem, Distributor } from "@/lib/database.types";
import { formatCurrency, formatDate, todayStr } from "@/lib/utils";

export default function PurchasesPage() {
  const supabase = createClient();
  const [purchases, setPurchases] = useState<(Purchase & { distributors: Pick<Distributor, "name"> | null; purchase_items: (PurchaseItem & { products: Pick<Product, "name"> })[] })[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [distributors, setDistributors] = useState<Distributor[]>([]);
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(true);

  const [date, setDate] = useState(todayStr());
  const [distributorId, setDistributorId] = useState("");
  const [productId, setProductId] = useState("");
  const [qty, setQty] = useState(1);
  const [price, setPrice] = useState(0);
  const [payment, setPayment] = useState("Transfer");
  const [notes, setNotes] = useState("");

  async function load() {
    setLoading(true);
    const [{ data: pu }, { data: p }, { data: d }] = await Promise.all([
      supabase.from("purchases").select("*, distributors(name), purchase_items(*, products(name))").order("date", { ascending: false }).limit(100),
      supabase.from("products").select("*").order("name"),
      supabase.from("distributors").select("*").order("name"),
    ]);
    setPurchases((pu as any) ?? []);
    setProducts((p as Product[]) ?? []);
    setDistributors((d as Distributor[]) ?? []);
    setLoading(false);
  }
  useEffect(() => { load(); }, []);

  function openAdd() {
    if (products.length === 0 || distributors.length === 0) return alert("Tambahkan produk & distributor terlebih dahulu");
    const firstP = products[0];
    setDistributorId(distributors[0].id); setProductId(firstP.id);
    setQty(1); setPrice(firstP.purchase_price); setPayment("Transfer"); setNotes(""); setDate(todayStr());
    setOpen(true);
  }
  function onProductChange(id: string) {
    setProductId(id);
    const p = products.find((x) => x.id === id);
    if (p) setPrice(p.purchase_price);
  }

  async function handleSave() {
    if (qty <= 0) return alert("Jumlah harus lebih dari 0");
    const number = "PO-" + String(purchases.length + 1).padStart(4, "0");
    const total = qty * price;
    const { data: purchase, error } = await supabase
      .from("purchases")
      .insert({ number, date, distributor_id: distributorId, payment_method: payment, notes, total })
      .select().single();
    if (error || !purchase) return alert("Gagal menyimpan pembelian: " + error?.message);
    await supabase.from("purchase_items").insert({ purchase_id: purchase.id, product_id: productId, quantity: qty, purchase_price: price });
    // stock increment + inventory log handled automatically by DB trigger
    setOpen(false);
    load();
  }

  async function handleDelete(id: string) {
    if (!confirm("Hapus data pembelian ini? Stok akan dikurangi kembali.")) return;
    await supabase.from("purchases").delete().eq("id", id);
    load();
  }

  return (
    <AppShell title="Pembelian" subtitle="Catat pembelian dari distributor">
      <div className="mb-4 flex justify-end"><Button onClick={openAdd}>+ Catat Pembelian</Button></div>
      <Card className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border text-left text-[11.5px] uppercase tracking-wide text-muted-foreground">
              <th className="p-3">No. PO</th><th className="p-3">Tanggal</th><th className="p-3">Distributor</th>
              <th className="p-3">Produk</th><th className="p-3">Total</th><th className="p-3">Pembayaran</th><th className="p-3" />
            </tr>
          </thead>
          <tbody>
            {loading && <tr><td colSpan={7} className="p-8 text-center text-muted-foreground">Memuat...</td></tr>}
            {!loading && purchases.length === 0 && <tr><td colSpan={7} className="p-8 text-center text-muted-foreground">Belum ada data pembelian.</td></tr>}
            {purchases.map((pu) => (
              <tr key={pu.id} className="border-b border-border hover:bg-muted/40">
                <td className="p-3">{pu.number}</td>
                <td className="p-3">{formatDate(pu.date)}</td>
                <td className="p-3">{pu.distributors?.name ?? "-"}</td>
                <td className="p-3">{pu.purchase_items.map((i) => i.products?.name).join(", ")}</td>
                <td className="p-3 font-semibold">{formatCurrency(pu.total)}</td>
                <td className="p-3">{pu.payment_method}</td>
                <td className="p-3"><Button size="sm" variant="danger" onClick={() => handleDelete(pu.id)}>Hapus</Button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>

      <Dialog open={open} onClose={() => setOpen(false)} title="Catat Pembelian" footer={<>
        <Button variant="outline" onClick={() => setOpen(false)}>Batal</Button>
        <Button onClick={handleSave}>Simpan</Button>
      </>}>
        <div className="space-y-3.5">
          <div><Label>Tanggal</Label><Input type="date" value={date} onChange={(e) => setDate(e.target.value)} /></div>
          <div><Label>Distributor</Label>
            <Select value={distributorId} onChange={(e) => setDistributorId(e.target.value)}>
              {distributors.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
            </Select>
          </div>
          <div><Label>Produk</Label>
            <Select value={productId} onChange={(e) => onProductChange(e.target.value)}>
              {products.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
            </Select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><Label>Jumlah</Label><Input type="number" min={1} value={qty} onChange={(e) => setQty(Number(e.target.value))} /></div>
            <div><Label>Harga Beli (per unit)</Label><Input type="number" value={price} onChange={(e) => setPrice(Number(e.target.value))} /></div>
          </div>
          <div><Label>Metode Pembayaran</Label>
            <Select value={payment} onChange={(e) => setPayment(e.target.value)}>
              <option>Transfer</option><option>Tunai</option><option>Kredit</option>
            </Select>
          </div>
          <div><Label>Catatan</Label><Textarea rows={2} value={notes} onChange={(e) => setNotes(e.target.value)} /></div>
        </div>
      </Dialog>
    </AppShell>
  );
}
