import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Tobacco Manager Pro",
  description: "Internal business management system — Tobacco Distribution & Retail",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="id" suppressHydrationWarning>
      <body className="font-sans antialiased">{children}</body>
    </html>
  );
}
