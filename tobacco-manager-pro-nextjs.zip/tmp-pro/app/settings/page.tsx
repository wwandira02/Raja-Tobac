"use client";
import { useEffect, useState } from "react";
import { AppShell } from "@/components/layout/app-shell";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input, Label } from "@/components/ui/input";
import { createClient } from "@/lib/supabase/client";

export default function SettingsPage() {
  const supabase = createClient();
  const [email, setEmail] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [message, setMessage] = useState<string | null>(null);

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => setEmail(data.user?.email ?? ""));
  }, []);

  async function handlePasswordChange() {
    if (newPassword.length < 8) return setMessage("Kata sandi minimal 8 karakter.");
    const { error } = await supabase.auth.updateUser({ password: newPassword });
    setMessage(error ? "Gagal memperbarui kata sandi: " + error.message : "Kata sandi berhasil diperbarui.");
    setNewPassword("");
  }

  return (
    <AppShell title="Pengaturan" subtitle="Akun pemilik dan preferensi sistem">
      <Card className="max-w-lg p-6">
        <h3 className="mb-4 font-display text-[15.5px]">Akun Pemilik</h3>
        <div className="mb-4">
          <Label>Email</Label>
          <Input disabled value={email} />
        </div>
        <div className="mb-4">
          <Label>Kata Sandi Baru</Label>
          <Input type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} placeholder="Minimal 8 karakter" />
        </div>
        {message && <p className="mb-3 text-sm text-muted-foreground">{message}</p>}
        <Button onClick={handlePasswordChange}>Perbarui Kata Sandi</Button>
      </Card>
      <Card className="mt-5 max-w-lg p-6">
        <h3 className="mb-2 font-display text-[15.5px]">Tentang Sistem</h3>
        <p className="text-sm text-muted-foreground">
          Tobacco Manager Pro v1.0 — sistem manajemen internal untuk distribusi &amp; ritel tembakau.
          Akses terbatas untuk pemilik usaha. Data disimpan di Supabase dengan Row Level Security aktif.
        </p>
      </Card>
    </AppShell>
  );
}
