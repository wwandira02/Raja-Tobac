import { AppShell } from "@/components/layout/app-shell";
import { StatCard } from "@/components/dashboard/stat-card";
import { DailySalesChart } from "@/components/charts/daily-sales-chart";
import { MonthlyRevenueChart } from "@/components/charts/monthly-revenue-chart";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { getProducts, getSales, getExpenses } from "@/lib/data";
import {
  totalRevenue, totalProfit, totalExpenses, inventoryValue, lowStockProducts, outOfStockProducts,
} from "@/lib/calculations";
import { formatCurrency, formatNumber, todayStr, monthStr } from "@/lib/utils";

export const revalidate = 0;

export default async function DashboardPage() {
  const [products, sales, expenses] = await Promise.all([getProducts(), getSales(), getExpenses()]);

  const today = todayStr();
  const month = monthStr();
  const todaySales = sales.filter((s) => s.date === today);
  const monthSales = sales.filter((s) => s.date.startsWith(month));
  const monthExpenses = expenses.filter((e) => e.date.startsWith(month)).reduce((a, e) => a + e.amount, 0);
  const monthProfit = totalProfit(monthSales);
  const netProfit = monthProfit - monthExpenses;

  const lowStock = lowStockProducts(products);
  const outStock = outOfStockProducts(products);

  const dailyData = Array.from({ length: 14 }).map((_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (13 - i));
    const ds = d.toISOString().slice(0, 10);
    const list = sales.filter((s) => s.date === ds);
    return {
      day: d.toLocaleDateString("id-ID", { day: "2-digit", month: "short" }),
      revenue: totalRevenue(list),
      profit: totalProfit(list),
    };
  });

  const monthlyData = Array.from({ length: 6 }).map((_, i) => {
    const d = new Date();
    d.setMonth(d.getMonth() - (5 - i));
    const mk = d.toISOString().slice(0, 7);
    return {
      month: d.toLocaleDateString("id-ID", { month: "short", year: "2-digit" }),
      revenue: totalRevenue(sales.filter((s) => s.date.startsWith(mk))),
    };
  });

  return (
    <AppShell title="Dashboard" subtitle="Ringkasan performa bisnis hari ini">
      <div className="mb-5 grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard label="Pendapatan Hari Ini" value={formatCurrency(totalRevenue(todaySales))} delta={`${todaySales.length} transaksi`} />
        <StatCard label="Pendapatan Bulan Ini" value={formatCurrency(totalRevenue(monthSales))} delta={month} />
        <StatCard label="Laba Hari Ini" value={formatCurrency(totalProfit(todaySales))} delta="margin kotor" />
        <StatCard label="Laba Bersih Bulan Ini" value={formatCurrency(netProfit)} delta="setelah pengeluaran" />
      </div>
      <div className="mb-6 grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard label="Nilai Inventaris" value={formatCurrency(inventoryValue(products))} delta="berdasar harga beli" />
        <StatCard label="Total Produk" value={formatNumber(products.length)} delta="jenis aktif" />
        <StatCard label="Total Pengeluaran" value={formatCurrency(totalExpenses(expenses))} delta="akumulatif" />
        <StatCard label="Laba Bulan Ini (Kotor)" value={formatCurrency(monthProfit)} delta="sebelum pengeluaran" />
      </div>

      <div className="mb-5 grid gap-4 lg:grid-cols-[2fr_1fr]">
        <Card>
          <CardHeader><CardTitle>Grafik Penjualan Harian (14 hari)</CardTitle></CardHeader>
          <CardContent><DailySalesChart data={dailyData} /></CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>Peringatan</CardTitle></CardHeader>
          <CardContent>
            {lowStock.length === 0 && outStock.length === 0 && (
              <p className="py-6 text-center text-sm text-muted-foreground">Tidak ada peringatan stok saat ini.</p>
            )}
            <div className="space-y-0">
              {outStock.map((p) => (
                <NotifRow key={p.id} color="#C62828" title={`${p.name} — stok habis`} desc="Segera lakukan pembelian ke distributor" />
              ))}
              {lowStock.map((p) => (
                <NotifRow key={p.id} color="#C9A227" title={`${p.name} — stok menipis (${p.stock} ${p.unit})`} desc={`Minimum ${p.min_stock} ${p.unit}`} />
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-[2fr_1fr]">
        <Card>
          <CardHeader><CardTitle>Pendapatan Bulanan (6 bulan terakhir)</CardTitle></CardHeader>
          <CardContent><MonthlyRevenueChart data={monthlyData} /></CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>Produk Terlaris</CardTitle></CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              Lihat halaman <strong>Laporan</strong> untuk rincian produk terlaris & paling menguntungkan.
            </p>
          </CardContent>
        </Card>
      </div>
    </AppShell>
  );
}

function NotifRow({ color, title, desc }: { color: string; title: string; desc: string }) {
  return (
    <div className="flex gap-2.5 border-b border-border py-2.5 last:border-none">
      <div className="mt-1.5 h-2 w-2 flex-shrink-0 rounded-full" style={{ background: color }} />
      <div>
        <div className="text-[13px] font-semibold">{title}</div>
        <div className="text-xs text-muted-foreground">{desc}</div>
      </div>
    </div>
  );
}
