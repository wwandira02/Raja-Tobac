"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { Button } from "@/components/ui/button";
import { Input, Label } from "@/components/ui/input";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    const supabase = createClient();
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (error) {
      setError("Email atau kata sandi salah.");
      return;
    }
    router.push("/");
    router.refresh();
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-brand-green900 p-5">
      <div className="w-full max-w-sm rounded-2xl border border-white/10 bg-[#132a17] p-8 shadow-2xl">
        <div className="mb-6 flex items-center gap-2.5">
          <div className="flex h-9 w-9 items-center justify-center rounded-[9px] bg-brand-gold font-display text-lg font-bold text-brand-green900">
            T
          </div>
          <div>
            <h1 className="font-display text-lg text-white">Tobacco Manager</h1>
            <p className="text-[11px] tracking-wide text-brand-goldSoft">PRO &middot; OWNER ACCESS ONLY</p>
          </div>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label className="text-brand-goldSoft/80">Email</Label>
            <Input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="border-white/15 bg-white/5 text-white"
              placeholder="owner@usaha-anda.com"
            />
          </div>
          <div>
            <Label className="text-brand-goldSoft/80">Kata Sandi</Label>
            <Input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="border-white/15 bg-white/5 text-white"
              placeholder="••••••••"
            />
          </div>
          {error && <p className="text-sm text-red-400">{error}</p>}
          <Button type="submit" variant="gold" disabled={loading} className="w-full justify-center">
            {loading ? "Memproses..." : "Masuk"}
          </Button>
        </form>
        <p className="mt-5 text-center text-[12px] text-white/40">
          Sistem internal — akses hanya untuk pemilik usaha.
        </p>
      </div>
    </div>
  );
}
