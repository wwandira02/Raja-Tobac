"use client";
import { useEffect, useState } from "react";
import { AppShell } from "@/components/layout/app-shell";
import { StatCard } from "@/components/dashboard/stat-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input, Label } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog } from "@/components/ui/dialog";
import { createClient } from "@/lib/supabase/client";
import type { Product, InventoryLog } from "@/lib/database.types";
import { formatCurrency, formatDate, todayStr } from "@/lib/utils";
import { inventoryValue } from "@/lib/calculations";

export default function InventoryPage() {
  const supabase = createClient();
  const [products, setProducts] = useState<Product[]>([]);
  const [logs, setLogs] = useState<(InventoryLog & { products: Pick<Product, "name"> | null })[]>([]);
  const [adjustTarget, setAdjustTarget] = useState<Product | null>(null);
  const [newStock, setNewStock] = useState(0);
  const [reason, setReason] = useState("");

  async function load() {
    const [{ data: p }, { data: l }] = await Promise.all([
      supabase.from("products").select("*").order("name"),
      supabase.from("inventory_logs").select("*, products(name)").order("date", { ascending: false }).limit(40),
    ]);
    setProducts((p as Product[]) ?? []);
    setLogs((l as any) ?? []);
  }
  useEffect(() => { load(); }, []);

  function openAdjust(p: Product) { setAdjustTarget(p); setNewStock(p.stock); setReason(""); }

  async function handleAdjust() {
    if (!adjustTarget) return;
    const diff = newStock - adjustTarget.stock;
    await supabase.from("products").update({ stock: newStock }).eq("id", adjustTarget.id);
    await supabase.from("inventory_logs").insert({
      date: todayStr(), product_id: adjustTarget.id, type: "adjust", quantity: Math.abs(diff),
      note: `${reason || "Penyesuaian manual"} (${diff >= 0 ? "+" : ""}${diff})`,
    });
    setAdjustTarget(null); load();
  }

  const totalIn = logs.filter((l) => l.type === "in").reduce((a, l) => a + l.quantity, 0);
  const totalOut = logs.filter((l) => l.type === "out").reduce((a, l) => a + l.quantity, 0);

  return (
    <AppShell title="Inventaris" subtitle="Pantau stok masuk, keluar, dan nilai persediaan">
      <div className="mb-5 grid gap-4 sm:grid-cols-3">
        <StatCard label="Nilai Inventaris Total" value={formatCurrency(inventoryValue(products))} delta="harga beli x stok" />
        <StatCard label="Stok Masuk (terbaru)" value={`${totalIn} unit`} delta="dari pembelian" />
        <StatCard label="Stok Keluar (terbaru)" value={`${totalOut} unit`} delta="dari penjualan" />
      </div>

      <Card className="mb-5 overflow-x-auto">
        <div className="p-5 pb-1"><h3 className="font-display text-[15.5px]">Stok Per Produk</h3></div>
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border text-left text-[11.5px] uppercase tracking-wide text-muted-foreground">
              <th className="p-3">Produk</th><th className="p-3">Stok</th><th className="p-3">Minimum</th>
              <th className="p-3">Nilai</th><th className="p-3">Status</th><th className="p-3" />
            </tr>
          </thead>
          <tbody>
            {products.map((p) => (
              <tr key={p.id} className="border-b border-border hover:bg-muted/40">
                <td className="p-3 font-semibold">{p.name}</td>
                <td className="p-3">{p.stock} {p.unit}</td>
                <td className="p-3">{p.min_stock} {p.unit}</td>
                <td className="p-3">{formatCurrency(p.stock * p.purchase_price)}</td>
                <td className="p-3">
                  {p.stock <= 0 ? <Badge tone="danger">Habis</Badge> :
                    p.stock <= p.min_stock ? <Badge tone="warn">Menipis</Badge> : <Badge tone="ok">Aman</Badge>}
                </td>
                <td className="p-3"><Button size="sm" variant="outline" onClick={() => openAdjust(p)}>Sesuaikan Stok</Button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>

      <Card className="overflow-x-auto">
        <div className="p-5 pb-1"><h3 className="font-display text-[15.5px]">Riwayat Pergerakan Stok</h3></div>
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border text-left text-[11.5px] uppercase tracking-wide text-muted-foreground">
              <th className="p-3">Tanggal</th><th className="p-3">Produk</th><th className="p-3">Jenis</th><th className="p-3">Jumlah</th><th className="p-3">Catatan</th>
            </tr>
          </thead>
          <tbody>
            {logs.length === 0 && <tr><td colSpan={5} className="p-8 text-center text-muted-foreground">Belum ada pergerakan stok.</td></tr>}
            {logs.map((l) => (
              <tr key={l.id} className="border-b border-border hover:bg-muted/40">
                <td className="p-3">{formatDate(l.date)}</td>
                <td className="p-3">{l.products?.name ?? "(dihapus)"}</td>
                <td className="p-3">
                  {l.type === "in" ? <Badge tone="ok">Masuk</Badge> : l.type === "out" ? <Badge tone="danger">Keluar</Badge> : <Badge tone="warn">Penyesuaian</Badge>}
                </td>
                <td className="p-3">{l.quantity}</td>
                <td className="p-3">{l.note}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>

      <Dialog open={!!adjustTarget} onClose={() => setAdjustTarget(null)} title={`Sesuaikan Stok — ${adjustTarget?.name ?? ""}`} footer={<>
        <Button variant="outline" onClick={() => setAdjustTarget(null)}>Batal</Button>
        <Button onClick={handleAdjust}>Simpan</Button>
      </>}>
        <div className="space-y-3.5">
          <div><Label>Stok Saat Ini</Label><Input disabled value={`${adjustTarget?.stock ?? 0} ${adjustTarget?.unit ?? ""}`} /></div>
          <div><Label>Stok Baru</Label><Input type="number" value={newStock} onChange={(e) => setNewStock(Number(e.target.value))} /></div>
          <div><Label>Alasan Penyesuaian</Label><Input value={reason} onChange={(e) => setReason(e.target.value)} placeholder="contoh: audit fisik, rusak, dsb." /></div>
        </div>
      </Dialog>
    </AppShell>
  );
}
