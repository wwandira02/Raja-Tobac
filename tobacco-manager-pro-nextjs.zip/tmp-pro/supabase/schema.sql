-- =========================================================
-- TOBACCO MANAGER PRO — Supabase schema
-- Run this in the Supabase SQL editor (or via `supabase db push`)
-- =========================================================

create extension if not exists "uuid-ossp";

-- ---------- USERS (extends Supabase auth.users) ----------
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  role text not null default 'owner' check (role in ('owner','staff')),
  created_at timestamptz not null default now()
);

-- ---------- DISTRIBUTORS ----------
create table if not exists public.distributors (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  phone text,
  address text,
  city text,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ---------- PRODUCTS ----------
create table if not exists public.products (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  category text,
  brand text,
  purchase_price numeric(14,2) not null default 0,
  selling_price numeric(14,2) not null default 0,
  stock numeric(14,2) not null default 0,
  min_stock numeric(14,2) not null default 0,
  unit text not null default 'pcs',
  image_url text,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- generated columns for automatic profit/margin calculations
alter table public.products
  add column if not exists profit_per_item numeric(14,2)
    generated always as (selling_price - purchase_price) stored;

alter table public.products
  add column if not exists margin_percent numeric(8,2)
    generated always as (
      case when purchase_price > 0
        then round(((selling_price - purchase_price) / purchase_price) * 100, 2)
        else 0
      end
    ) stored;

-- ---------- PURCHASES (header + line items) ----------
create table if not exists public.purchases (
  id uuid primary key default uuid_generate_v4(),
  number text not null unique,
  date date not null default current_date,
  distributor_id uuid references public.distributors(id) on delete set null,
  payment_method text not null default 'Transfer',
  notes text,
  total numeric(14,2) not null default 0,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);

create table if not exists public.purchase_items (
  id uuid primary key default uuid_generate_v4(),
  purchase_id uuid not null references public.purchases(id) on delete cascade,
  product_id uuid not null references public.products(id) on delete restrict,
  quantity numeric(14,2) not null,
  purchase_price numeric(14,2) not null,
  subtotal numeric(14,2) generated always as (quantity * purchase_price) stored
);

-- ---------- SALES (header + line items) ----------
create table if not exists public.sales (
  id uuid primary key default uuid_generate_v4(),
  number text not null unique,
  date date not null default current_date,
  notes text,
  total numeric(14,2) not null default 0,
  profit numeric(14,2) not null default 0,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);

create table if not exists public.sale_items (
  id uuid primary key default uuid_generate_v4(),
  sale_id uuid not null references public.sales(id) on delete cascade,
  product_id uuid not null references public.products(id) on delete restrict,
  quantity numeric(14,2) not null,
  selling_price numeric(14,2) not null,
  purchase_price_snapshot numeric(14,2) not null default 0,
  subtotal numeric(14,2) generated always as (quantity * selling_price) stored,
  profit numeric(14,2) generated always as (quantity * (selling_price - purchase_price_snapshot)) stored
);

-- ---------- EXPENSES ----------
create table if not exists public.expenses (
  id uuid primary key default uuid_generate_v4(),
  date date not null default current_date,
  category text not null check (category in
    ('Transportasi','Operasional','Kemasan','Listrik & Utilitas','Gaji Karyawan','Lain-lain')),
  amount numeric(14,2) not null,
  description text,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);

-- ---------- INVENTORY LOGS ----------
create table if not exists public.inventory_logs (
  id uuid primary key default uuid_generate_v4(),
  date date not null default current_date,
  product_id uuid not null references public.products(id) on delete cascade,
  type text not null check (type in ('in','out','adjust')),
  quantity numeric(14,2) not null,
  note text,
  ref_table text,
  ref_id uuid,
  created_at timestamptz not null default now()
);

-- =========================================================
-- TRIGGERS: keep stock + inventory_logs in sync automatically
-- =========================================================

-- Purchases: increase stock + log when a purchase_item is inserted
create or replace function public.fn_purchase_item_insert() returns trigger as $$
begin
  update public.products set stock = stock + new.quantity, updated_at = now()
    where id = new.product_id;
  insert into public.inventory_logs (date, product_id, type, quantity, note, ref_table, ref_id)
    select p.date, new.product_id, 'in', new.quantity, 'Pembelian ' || p.number, 'purchases', p.id
    from public.purchases p where p.id = new.purchase_id;
  return new;
end;
$$ language plpgsql;

drop trigger if exists trg_purchase_item_insert on public.purchase_items;
create trigger trg_purchase_item_insert
  after insert on public.purchase_items
  for each row execute function public.fn_purchase_item_insert();

-- Purchases: reverse stock on delete
create or replace function public.fn_purchase_item_delete() returns trigger as $$
begin
  update public.products set stock = greatest(0, stock - old.quantity), updated_at = now()
    where id = old.product_id;
  return old;
end;
$$ language plpgsql;

drop trigger if exists trg_purchase_item_delete on public.purchase_items;
create trigger trg_purchase_item_delete
  after delete on public.purchase_items
  for each row execute function public.fn_purchase_item_delete();

-- Sales: decrease stock + log when a sale_item is inserted
create or replace function public.fn_sale_item_insert() returns trigger as $$
begin
  update public.products set stock = stock - new.quantity, updated_at = now()
    where id = new.product_id;
  insert into public.inventory_logs (date, product_id, type, quantity, note, ref_table, ref_id)
    select s.date, new.product_id, 'out', new.quantity, 'Penjualan ' || s.number, 'sales', s.id
    from public.sales s where s.id = new.sale_id;
  return new;
end;
$$ language plpgsql;

drop trigger if exists trg_sale_item_insert on public.sale_items;
create trigger trg_sale_item_insert
  after insert on public.sale_items
  for each row execute function public.fn_sale_item_insert();

-- Sales: restore stock on delete
create or replace function public.fn_sale_item_delete() returns trigger as $$
begin
  update public.products set stock = stock + old.quantity, updated_at = now()
    where id = old.product_id;
  return old;
end;
$$ language plpgsql;

drop trigger if exists trg_sale_item_delete on public.sale_items;
create trigger trg_sale_item_delete
  after delete on public.sale_items
  for each row execute function public.fn_sale_item_delete();

-- =========================================================
-- ROW LEVEL SECURITY — owner-only internal system
-- =========================================================
alter table public.profiles enable row level security;
alter table public.distributors enable row level security;
alter table public.products enable row level security;
alter table public.purchases enable row level security;
alter table public.purchase_items enable row level security;
alter table public.sales enable row level security;
alter table public.sale_items enable row level security;
alter table public.expenses enable row level security;
alter table public.inventory_logs enable row level security;

-- Simple policy: any authenticated user tied to this project can read/write.
-- Tighten with a role check on profiles.role if you add staff accounts later.
create policy "auth read/write distributors" on public.distributors for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');
create policy "auth read/write products" on public.products for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');
create policy "auth read/write purchases" on public.purchases for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');
create policy "auth read/write purchase_items" on public.purchase_items for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');
create policy "auth read/write sales" on public.sales for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');
create policy "auth read/write sale_items" on public.sale_items for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');
create policy "auth read/write expenses" on public.expenses for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');
create policy "auth read/write inventory_logs" on public.inventory_logs for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');
create policy "own profile" on public.profiles for all using (auth.uid() = id) with check (auth.uid() = id);

-- =========================================================
-- INDEXES
-- =========================================================
create index if not exists idx_sale_items_product on public.sale_items(product_id);
create index if not exists idx_purchase_items_product on public.purchase_items(product_id);
create index if not exists idx_sales_date on public.sales(date);
create index if not exists idx_purchases_date on public.purchases(date);
create index if not exists idx_expenses_date on public.expenses(date);
create index if not exists idx_inventory_logs_product on public.inventory_logs(product_id);
