// Minimal hand-written types mirroring supabase/schema.sql.
// Regenerate with `supabase gen types typescript` once your project is linked
// for full accuracy (auto-generated types will replace this file).

export type Product = {
  id: string;
  name: string;
  category: string | null;
  brand: string | null;
  purchase_price: number;
  selling_price: number;
  stock: number;
  min_stock: number;
  unit: string;
  image_url: string | null;
  notes: string | null;
  profit_per_item: number;
  margin_percent: number;
  created_at: string;
  updated_at: string;
};

export type Distributor = {
  id: string;
  name: string;
  phone: string | null;
  address: string | null;
  city: string | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
};

export type Sale = {
  id: string;
  number: string;
  date: string;
  notes: string | null;
  total: number;
  profit: number;
  created_by: string | null;
  created_at: string;
};

export type SaleItem = {
  id: string;
  sale_id: string;
  product_id: string;
  quantity: number;
  selling_price: number;
  purchase_price_snapshot: number;
  subtotal: number;
  profit: number;
};

export type Purchase = {
  id: string;
  number: string;
  date: string;
  distributor_id: string | null;
  payment_method: string;
  notes: string | null;
  total: number;
  created_by: string | null;
  created_at: string;
};

export type PurchaseItem = {
  id: string;
  purchase_id: string;
  product_id: string;
  quantity: number;
  purchase_price: number;
  subtotal: number;
};

export type Expense = {
  id: string;
  date: string;
  category:
    | "Transportasi"
    | "Operasional"
    | "Kemasan"
    | "Listrik & Utilitas"
    | "Gaji Karyawan"
    | "Lain-lain";
  amount: number;
  description: string | null;
  created_by: string | null;
  created_at: string;
};

export type InventoryLog = {
  id: string;
  date: string;
  product_id: string;
  type: "in" | "out" | "adjust";
  quantity: number;
  note: string | null;
  ref_table: string | null;
  ref_id: string | null;
  created_at: string;
};

// Generic placeholder so `createClient<Database>()` type-checks.
// Replace with the full generated schema for strict query typing.
export type Database = {
  public: {
    Tables: Record<string, { Row: any; Insert: any; Update: any }>;
  };
};
