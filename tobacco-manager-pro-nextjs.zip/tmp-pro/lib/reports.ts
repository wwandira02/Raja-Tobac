import type { Sale, Expense } from "@/lib/database.types";
import { totalRevenue, totalProfit, totalExpenses } from "@/lib/calculations";

export type PeriodReport = {
  label: string;
  revenue: number;
  grossProfit: number;
  expenses: number;
  netProfit: number;
};

function inRange(dateStr: string, from: string, to: string) {
  return dateStr >= from && dateStr <= to;
}

export function buildPeriodReport(
  label: string,
  sales: Sale[],
  expenses: Expense[],
  from: string,
  to: string
): PeriodReport {
  const s = sales.filter((x) => inRange(x.date, from, to));
  const e = expenses.filter((x) => inRange(x.date, from, to));
  const revenue = totalRevenue(s);
  const grossProfit = totalProfit(s);
  const exp = totalExpenses(e);
  return { label, revenue, grossProfit, expenses: exp, netProfit: grossProfit - exp };
}

/** Year-over-year revenue growth percentage, or null if no prior-year data. */
export function revenueGrowth(currentYearSales: Sale[], lastYearSales: Sale[]): number | null {
  const prev = totalRevenue(lastYearSales);
  if (prev <= 0) return null;
  const curr = totalRevenue(currentYearSales);
  return ((curr - prev) / prev) * 100;
}

/** Aggregate quantity sold per product, sorted descending. */
export function topSellingProducts(
  sales: Sale[],
  saleItems: { sale_id: string; product_id: string; quantity: number }[],
  limit = 5
): { productId: string; quantity: number }[] {
  const saleIds = new Set(sales.map((s) => s.id));
  const agg: Record<string, number> = {};
  for (const item of saleItems) {
    if (!saleIds.has(item.sale_id)) continue;
    agg[item.product_id] = (agg[item.product_id] || 0) + item.quantity;
  }
  return Object.entries(agg)
    .map(([productId, quantity]) => ({ productId, quantity }))
    .sort((a, b) => b.quantity - a.quantity)
    .slice(0, limit);
}

/** Aggregate profit per product, sorted descending. */
export function mostProfitableProducts(
  saleItems: { product_id: string; profit: number }[],
  limit = 6
): { productId: string; profit: number }[] {
  const agg: Record<string, number> = {};
  for (const item of saleItems) {
    agg[item.product_id] = (agg[item.product_id] || 0) + item.profit;
  }
  return Object.entries(agg)
    .map(([productId, profit]) => ({ productId, profit }))
    .sort((a, b) => b.profit - a.profit)
    .slice(0, limit);
}
