import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatCurrency(n: number): string {
  return "Rp " + Math.round(n || 0).toLocaleString("id-ID");
}

export function formatNumber(n: number): string {
  return (n || 0).toLocaleString("id-ID");
}

export function formatDate(d: string | Date): string {
  return new Date(d).toLocaleDateString("id-ID", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
}

export function todayStr(): string {
  return new Date().toISOString().slice(0, 10);
}

export function monthStr(d: Date = new Date()): string {
  return d.toISOString().slice(0, 7);
}
