import type { Product, Sale, Expense } from "@/lib/database.types";

/** Profit per single unit sold = selling price - purchase price. */
export function profitPerItem(product: Pick<Product, "selling_price" | "purchase_price">): number {
  return product.selling_price - product.purchase_price;
}

/** Margin percentage = ((selling - purchase) / purchase) * 100 */
export function marginPercent(product: Pick<Product, "selling_price" | "purchase_price">): number {
  if (!product.purchase_price) return 0;
  return ((product.selling_price - product.purchase_price) / product.purchase_price) * 100;
}

/** Current inventory value, valued at purchase price. */
export function inventoryValue(products: Pick<Product, "stock" | "purchase_price">[]): number {
  return products.reduce((sum, p) => sum + p.stock * p.purchase_price, 0);
}

export function totalRevenue(sales: Pick<Sale, "total">[]): number {
  return sales.reduce((sum, s) => sum + s.total, 0);
}

export function totalProfit(sales: Pick<Sale, "profit">[]): number {
  return sales.reduce((sum, s) => sum + s.profit, 0);
}

export function totalExpenses(expenses: Pick<Expense, "amount">[]): number {
  return expenses.reduce((sum, e) => sum + e.amount, 0);
}

export function netProfit(sales: Pick<Sale, "profit">[], expenses: Pick<Expense, "amount">[]): number {
  return totalProfit(sales) - totalExpenses(expenses);
}

export function lowStockProducts(products: Product[]): Product[] {
  return products.filter((p) => p.stock > 0 && p.stock <= p.min_stock);
}

export function outOfStockProducts(products: Product[]): Product[] {
  return products.filter((p) => p.stock <= 0);
}
