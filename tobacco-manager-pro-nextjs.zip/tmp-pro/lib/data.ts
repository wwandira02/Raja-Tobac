import { createClient } from "@/lib/supabase/server";
import type { Product, Sale, SaleItem, Purchase, PurchaseItem, Distributor, Expense, InventoryLog } from "@/lib/database.types";

// Thin server-side data-fetching helpers used by Server Components.
// Each simply wraps a Supabase query — swap freely for React Query / SWR on the client if preferred.

export async function getProducts(): Promise<Product[]> {
  const supabase = await createClient();
  const { data } = await supabase.from("products").select("*").order("name");
  return (data as Product[]) ?? [];
}

export async function getDistributors(): Promise<Distributor[]> {
  const supabase = await createClient();
  const { data } = await supabase.from("distributors").select("*").order("name");
  return (data as Distributor[]) ?? [];
}

export async function getSales(): Promise<Sale[]> {
  const supabase = await createClient();
  const { data } = await supabase.from("sales").select("*").order("date", { ascending: false });
  return (data as Sale[]) ?? [];
}

export async function getSaleItems(): Promise<SaleItem[]> {
  const supabase = await createClient();
  const { data } = await supabase.from("sale_items").select("*");
  return (data as SaleItem[]) ?? [];
}

export async function getPurchases(): Promise<Purchase[]> {
  const supabase = await createClient();
  const { data } = await supabase.from("purchases").select("*").order("date", { ascending: false });
  return (data as Purchase[]) ?? [];
}

export async function getPurchaseItems(): Promise<PurchaseItem[]> {
  const supabase = await createClient();
  const { data } = await supabase.from("purchase_items").select("*");
  return (data as PurchaseItem[]) ?? [];
}

export async function getExpenses(): Promise<Expense[]> {
  const supabase = await createClient();
  const { data } = await supabase.from("expenses").select("*").order("date", { ascending: false });
  return (data as Expense[]) ?? [];
}

export async function getInventoryLogs(): Promise<InventoryLog[]> {
  const supabase = await createClient();
  const { data } = await supabase
    .from("inventory_logs")
    .select("*")
    .order("date", { ascending: false })
    .limit(50);
  return (data as InventoryLog[]) ?? [];
}
