import { cn } from "@/lib/utils";

type Tone = "ok" | "warn" | "danger";

const toneClasses: Record<Tone, string> = {
  ok: "bg-brand-green800/10 text-brand-green800 dark:bg-green-500/15 dark:text-green-400",
  warn: "bg-brand-gold/15 text-[#8A6D00] dark:bg-brand-gold/20 dark:text-brand-goldSoft",
  danger: "bg-red-600/10 text-red-600 dark:bg-red-500/15 dark:text-red-400",
};

export function Badge({ tone, children }: { tone: Tone; children: React.ReactNode }) {
  return (
    <span className={cn("inline-block rounded-full px-2.5 py-0.5 text-[11px] font-semibold", toneClasses[tone])}>
      {children}
    </span>
  );
}
