import * as React from "react";
import { cn } from "@/lib/utils";

type Variant = "primary" | "gold" | "outline" | "danger" | "ghost";
type Size = "default" | "sm";

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
}

const variantClasses: Record<Variant, string> = {
  primary: "bg-brand-green800 text-white hover:opacity-90",
  gold: "bg-brand-gold text-[#26210B] hover:opacity-90",
  outline: "bg-transparent border border-border text-foreground hover:bg-muted",
  danger: "bg-red-600 text-white hover:opacity-90",
  ghost: "bg-transparent hover:bg-muted",
};

const sizeClasses: Record<Size, string> = {
  default: "px-4 py-2 text-sm",
  sm: "px-2.5 py-1.5 text-xs",
};

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = "primary", size = "default", ...props }, ref) => (
    <button
      ref={ref}
      className={cn(
        "inline-flex items-center gap-2 rounded-md font-semibold transition-opacity disabled:opacity-50 disabled:cursor-not-allowed",
        variantClasses[variant],
        sizeClasses[size],
        className
      )}
      {...props}
    />
  )
);
Button.displayName = "Button";
