"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard, Package, ShoppingCart, Truck, Warehouse, Users, Receipt, FileBarChart, Settings,
} from "lucide-react";
import { NAV_ITEMS } from "./nav-items";
import { cn } from "@/lib/utils";

const ICONS: Record<string, React.ElementType> = {
  LayoutDashboard, Package, ShoppingCart, Truck, Warehouse, Users, Receipt, FileBarChart, Settings,
};

export function Sidebar({ open, onNavigate }: { open: boolean; onNavigate: () => void }) {
  const pathname = usePathname();
  return (
    <aside
      className={cn(
        "fixed left-0 top-0 bottom-0 z-40 w-[250px] flex-shrink-0 bg-gradient-to-b from-brand-green900 to-brand-green800 text-[#EFEAD8] transition-transform duration-200 flex flex-col",
        "md:translate-x-0",
        open ? "translate-x-0" : "-translate-x-full"
      )}
    >
      <div className="border-b border-white/10 p-5 pb-4">
        <div className="flex items-center gap-2.5">
          <div className="flex h-[34px] w-[34px] items-center justify-center rounded-[9px] bg-brand-gold font-display text-base font-bold text-brand-green900">
            T
          </div>
          <div>
            <h1 className="text-[18px] font-semibold text-white">Tobacco Manager</h1>
            <p className="mt-0.5 text-[11.5px] tracking-wide text-brand-goldSoft">PRO &middot; INTERNAL SYSTEM</p>
          </div>
        </div>
      </div>
      <nav className="flex-1 overflow-y-auto p-3">
        {NAV_ITEMS.map((item) => {
          const Icon = ICONS[item.icon];
          const active = pathname === item.href;
          return (
            <Link
              key={item.href}
              href={item.href}
              onClick={onNavigate}
              className={cn(
                "mb-0.5 flex items-center gap-3 rounded-md border-l-[3px] border-transparent px-3 py-2.5 text-sm text-[#D9D6C8] transition-colors hover:bg-white/[0.06] hover:text-white",
                active && "border-brand-gold bg-brand-gold/15 text-white"
              )}
            >
              <Icon size={17} />
              <span>{item.label}</span>
            </Link>
          );
        })}
      </nav>
      <div className="border-t border-white/10 p-4 px-5 text-[11.5px] text-[#8FA893]">
        Signed in as <strong className="text-[#EFEAD8]">Owner</strong>
        <br />v1.0 &middot; Supabase mode
      </div>
    </aside>
  );
}
