"use client";
import { useEffect, useState } from "react";
import { Menu, Sun, Moon, LogOut } from "lucide-react";
import { createClient } from "@/lib/supabase/client";
import { useRouter } from "next/navigation";

export function Topbar({
  title,
  subtitle,
  onMenuClick,
}: {
  title: string;
  subtitle: string;
  onMenuClick: () => void;
}) {
  const [dark, setDark] = useState(false);
  const router = useRouter();

  useEffect(() => {
    const stored = localStorage.getItem("tmp_theme");
    const isDark = stored === "dark";
    setDark(isDark);
    document.documentElement.classList.toggle("dark", isDark);
  }, []);

  function toggleTheme() {
    const next = !dark;
    setDark(next);
    document.documentElement.classList.toggle("dark", next);
    localStorage.setItem("tmp_theme", next ? "dark" : "light");
  }

  async function handleLogout() {
    const supabase = createClient();
    await supabase.auth.signOut();
    router.push("/login");
    router.refresh();
  }

  return (
    <div className="sticky top-0 z-30 flex h-16 items-center justify-between border-b border-border bg-card px-6">
      <div className="flex items-center gap-3.5">
        <button onClick={onMenuClick} className="rounded-md p-1.5 md:hidden">
          <Menu size={22} />
        </button>
        <div>
          <h2 className="font-display text-[19px]">{title}</h2>
          <div className="mt-0.5 text-[12.5px] text-muted-foreground">{subtitle}</div>
        </div>
      </div>
      <div className="flex items-center gap-2.5">
        <button
          onClick={toggleTheme}
          className="flex h-[38px] w-[38px] items-center justify-center rounded-md border border-border"
          title="Ganti tema"
        >
          {dark ? <Moon size={18} /> : <Sun size={18} />}
        </button>
        <button
          onClick={handleLogout}
          className="flex h-[38px] w-[38px] items-center justify-center rounded-md border border-border"
          title="Keluar"
        >
          <LogOut size={18} />
        </button>
      </div>
    </div>
  );
}
