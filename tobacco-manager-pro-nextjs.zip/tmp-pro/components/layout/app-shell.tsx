"use client";
import { useState } from "react";
import { Sidebar } from "./sidebar";
import { Topbar } from "./topbar";
import { cn } from "@/lib/utils";

export function AppShell({
  title,
  subtitle,
  children,
}: {
  title: string;
  subtitle: string;
  children: React.ReactNode;
}) {
  const [open, setOpen] = useState(false);
  return (
    <div className="flex min-h-screen">
      <Sidebar open={open} onNavigate={() => setOpen(false)} />
      <div
        className={cn("fixed inset-0 z-30 bg-black/40 md:hidden", open ? "block" : "hidden")}
        onClick={() => setOpen(false)}
      />
      <div className="flex min-w-0 flex-1 flex-col md:ml-[250px]">
        <Topbar title={title} subtitle={subtitle} onMenuClick={() => setOpen(true)} />
        <div className="mx-auto w-full max-w-[1400px] flex-1 p-6">{children}</div>
      </div>
    </div>
  );
}
