export const NAV_ITEMS = [
  { href: "/", label: "Dashboard", icon: "LayoutDashboard" },
  { href: "/products", label: "Produk", icon: "Package" },
  { href: "/sales", label: "Penjualan", icon: "ShoppingCart" },
  { href: "/purchases", label: "Pembelian", icon: "Truck" },
  { href: "/inventory", label: "Inventaris", icon: "Warehouse" },
  { href: "/distributors", label: "Distributor", icon: "Users" },
  { href: "/expenses", label: "Pengeluaran", icon: "Receipt" },
  { href: "/reports", label: "Laporan", icon: "FileBarChart" },
  { href: "/settings", label: "Pengaturan", icon: "Settings" },
] as const;
