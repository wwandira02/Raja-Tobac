export function StatCard({ label, value, delta }: { label: string; value: string; delta: string }) {
  return (
    <div className="stat-bar relative overflow-hidden rounded-lg border border-border bg-card p-5 shadow-sm">
      <div className="text-xs text-muted-foreground">{label}</div>
      <div className="mt-1.5 font-display text-2xl font-bold">{value}</div>
      <div className="mt-1.5 inline-flex items-center gap-1 rounded-full bg-brand-green800/10 px-2.5 py-0.5 text-[11.5px] text-brand-green800 dark:bg-green-500/15 dark:text-green-400">
        {delta}
      </div>
    </div>
  );
}
