"use client";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";

export function DailySalesChart({ data }: { data: { day: string; revenue: number; profit: number }[] }) {
  return (
    <ResponsiveContainer width="100%" height={280}>
      <AreaChart data={data}>
        <defs>
          <linearGradient id="rev" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="#1B5E20" stopOpacity={0.3} />
            <stop offset="95%" stopColor="#1B5E20" stopOpacity={0} />
          </linearGradient>
          <linearGradient id="prof" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="#C9A227" stopOpacity={0.3} />
            <stop offset="95%" stopColor="#C9A227" stopOpacity={0} />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" vertical={false} className="stroke-border" />
        <XAxis dataKey="day" fontSize={11} tickLine={false} axisLine={false} />
        <YAxis
          fontSize={11}
          tickLine={false}
          axisLine={false}
          tickFormatter={(v) => (v >= 1e6 ? `${(v / 1e6).toFixed(1)}jt` : v >= 1e3 ? `${v / 1e3}rb` : v)}
        />
        <Tooltip formatter={(v: number) => "Rp " + v.toLocaleString("id-ID")} />
        <Legend wrapperStyle={{ fontSize: 12 }} />
        <Area type="monotone" dataKey="revenue" name="Pendapatan" stroke="#1B5E20" fill="url(#rev)" strokeWidth={2} />
        <Area type="monotone" dataKey="profit" name="Laba" stroke="#C9A227" fill="url(#prof)" strokeWidth={2} />
      </AreaChart>
    </ResponsiveContainer>
  );
}
